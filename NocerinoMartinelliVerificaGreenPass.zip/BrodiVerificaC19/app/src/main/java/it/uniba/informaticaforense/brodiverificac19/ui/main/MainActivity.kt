package it.uniba.informaticaforense.brodiverificac19.ui.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.viewModels
import com.google.zxing.client.android.Intents
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import dagger.hilt.android.AndroidEntryPoint
import it.ministerodellasalute.verificaC19sdk.VerificaMinVersionException
import it.ministerodellasalute.verificaC19sdk.model.VerificationViewModel
import it.uniba.informaticaforense.brodiverificac19.BuildConfig
import it.uniba.informaticaforense.brodiverificac19.R
import it.uniba.informaticaforense.brodiverificac19.ui.FirstActivity

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

//        private val viewModel by viewModels<VerificationViewModel>()
//        private val barcodeLauncher: ActivityResultLauncher<ScanOptions> =
//
//        registerForActivityResult<ScanOptions, ScanIntentResult>(
//            ScanContract(),
//            ActivityResultCallback { result: ScanIntentResult ->
//                if (result.getContents() == null) {
//                    val originalIntent: Intent = result.getOriginalIntent()
//                    if (originalIntent == null) {
//                        Log.d("MainActivity", "Cancelled scan")
//                        Toast.makeText(
//                            this,
//                            "Cancelled",
//                            Toast.LENGTH_LONG
//                        ).show()
//                    } else if (originalIntent.hasExtra(Intents.Scan.MISSING_CAMERA_PERMISSION)) {
//                        Log.d(
//                            "MainActivity",
//                            "Cancelled scan due to missing camera permission"
//                        )
//                        Toast.makeText(
//                            this,
//                            "Cancelled due to missing camera permission",
//                            Toast.LENGTH_LONG
//                        ).show()
//                    }
//                } else {
//
//                    try {
//                        viewModel.init(result.getContents())
//                        var certificate = viewModel.certificate
//                        Log.d("MainActivity", certificate.toString())
//                    }
//                    catch (e: VerificaMinVersionException)
//                    {
//                        Log.d("VerificationFragment", "Min Version Exception")
//                    }
//                    catch (e: Exception)
//                    {
//                        Log.d(e.cause.toString(),e.message + e.stackTraceToString())
//                    }
//
//                    Toast.makeText(
//                        this,
//                        "Scanned: " + result.getContents(),
//                        Toast.LENGTH_LONG
//                    ).show()
//                }
//            })


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.DEBUG) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }
//        val options = ScanOptions()
//        options.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
//        options.setPrompt("Scan something")
//        options.setOrientationLocked(false)
//        options.setBeepEnabled(false)

//        barcodeLauncher.launch(options)

        setContentView(R.layout.activity_main)
    }
}