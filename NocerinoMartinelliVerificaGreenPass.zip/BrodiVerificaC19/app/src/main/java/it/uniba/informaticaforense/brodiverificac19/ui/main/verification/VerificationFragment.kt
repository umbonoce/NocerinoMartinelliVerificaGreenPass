///*
// *  ---license-start
// *  eu-digital-green-certificates / dgca-verifier-app-android
// *  ---
// *  Copyright (C) 2021 T-Systems International GmbH and all other contributors
// *  ---
// *  Licensed under the Apache License, Version 2.0 (the "License");
// *  you may not use this file except in compliance with the License.
// *  You may obtain a copy of the License at
// *
// *       http://www.apache.org/licenses/LICENSE-2.0
// *
// *  Unless required by applicable law or agreed to in writing, software
// *  distributed under the License is distributed on an "AS IS" BASIS,
// *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// *  See the License for the specific language governing permissions and
// *  limitations under the License.
// *  ---license-end
// */
//
package it.uniba.informaticaforense.brodiverificac19.ui.main.verification

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.motion.widget.Key.VISIBILITY
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.zxing.client.android.Intents
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import dagger.hilt.android.AndroidEntryPoint
import it.uniba.informaticaforense.brodiverificac19.ui.main.verification.VerificationFragmentArgs
import it.uniba.informaticaforense.brodiverificac19.R
import it.uniba.informaticaforense.brodiverificac19.databinding.FragmentVerificationNewBinding
import it.uniba.informaticaforense.brodiverificac19.ui.base.isDebug
import it.uniba.informaticaforense.brodiverificac19.ui.compounds.QuestionCompound
import it.ministerodellasalute.verificaC19sdk.VerificaDownloadInProgressException
import it.ministerodellasalute.verificaC19sdk.VerificaMinSDKVersionException
import it.ministerodellasalute.verificaC19sdk.VerificaMinVersionException
import it.ministerodellasalute.verificaC19sdk.model.*
import it.ministerodellasalute.verificaC19sdk.util.FORMATTED_VALIDATION_DATE
import it.ministerodellasalute.verificaC19sdk.util.TimeUtility.formatDateOfBirth
import it.ministerodellasalute.verificaC19sdk.util.TimeUtility.parseTo
import java.util.*

@ExperimentalUnsignedTypes
@AndroidEntryPoint
class VerificationFragment : Fragment(), View.OnClickListener {

    private val args by navArgs<VerificationFragmentArgs>()
    private val viewModel by viewModels<VerificationViewModel>()

//    private val barcodeLauncher: ActivityResultLauncher<ScanOptions> =
//        registerForActivityResult<ScanOptions, ScanIntentResult>(
//            ScanContract(),
//            ActivityResultCallback { result: ScanIntentResult ->
//                if (result.getContents() == null) {
//                    val originalIntent: Intent = result.getOriginalIntent()
//                    if (originalIntent == null) {
//                        Log.d("MainActivity", "Cancelled scan")
//                        Toast.makeText(
//                            this.context,
//                            "Cancelled",
//                            Toast.LENGTH_LONG
//                        ).show()
//                    } else if (originalIntent.hasExtra(Intents.Scan.MISSING_CAMERA_PERMISSION)) {
//                        Log.d(
//                            "MainActivity",
//                            "Cancelled scan due to missing camera permission"
//                        )
//                        Toast.makeText(
//                            this.context,
//                            "Cancelled due to missing camera permission",
//                            Toast.LENGTH_LONG
//                        ).show()
//                    }
//                } else {
//
//                    try {
//                        viewModel.init(result.getContents())
//                        var certificate = viewModel.certificate
//                        Log.d("MainActivity", certificate.toString())
//                    }
//                    catch (e: VerificaMinVersionException)
//                    {
//                        Log.d("VerificationFragment", "Min Version Exception")
//                        createForceUpdateDialog(e.message.toString())
//                    }
//                    catch (e: Exception)
//                    {
//                        Log.d(e.cause.toString(),e.message + e.stackTraceToString())
//                    }
//
//                    Toast.makeText(
//                        this.context,
//                        "Scanned: " + result.getContents(),
//                        Toast.LENGTH_LONG
//                    ).show()
//                }
//            })

    private var _binding: FragmentVerificationNewBinding? = null
    private val binding get() = _binding!!
    private lateinit var certificateModel: CertificateViewBean

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVerificationNewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.closeButton.setOnClickListener(this)
        viewModel.certificate.observe(viewLifecycleOwner) { certificate ->
            certificate?.let {
                certificateModel = it
                setPersonData(it.person, it.dateOfBirth)
                setupCertStatusView(it)
                setupTimeStamp(it)
                if (
                    viewModel.getTotemMode() &&
                    (certificate.certificateStatus == CertificateStatus.VALID)
                ) {
                    Handler().postDelayed({
                        activity?.onBackPressed()
                    }, 5000)
                }
            }
        }
        viewModel.certificateModel.observe(viewLifecycleOwner) { certificate ->
            certificate?.let {
                Log.d("VerificationFragment", it.toString())

                setCertificateData(it)

            }
        }

        viewModel.inProgress.observe(viewLifecycleOwner) {
            binding.progressBar.isVisible = it
        }
        try {
            viewModel.init(args.qrCodeText, true)

        } catch (e: VerificaMinSDKVersionException) {
            Log.d("VerificationFragment", "Min SDK Version Exception")
            createForceUpdateDialog(getString(R.string.updateMessage))
        } catch (e: VerificaMinVersionException) {
            Log.d("VerificationFragment", "Min App Version Exception")
            createForceUpdateDialog(getString(R.string.updateMessage))
        } catch (e: VerificaDownloadInProgressException) {
            Log.d("VerificationFragment", "Download In Progress Exception")
            createForceUpdateDialog(getString(R.string.messageDownloadStarted))
        }
    }

    private fun setupCertStatusView(cert: CertificateViewBean) {
        cert.certificateStatus?.let {
            setBackgroundColor(it)
            setPersonDetailsVisibility(it)
            setValidationIcon(it)
            setValidationMainText(it)
            setValidationSubTextVisibility(it)
            setValidationSubText(it)
            setLinkViews(it)
            setScanModeText()
        }
    }

    private fun setScanModeText() {
        val chosenScanMode = when (viewModel.getScanMode()) {
            ScanMode.STANDARD -> getString(R.string.scan_mode_3G_header).substringAfter(' ')
                .uppercase(Locale.ROOT)
            ScanMode.STRENGTHENED -> getString(R.string.scan_mode_2G_header).substringAfter(' ')
                .uppercase(Locale.ROOT)
            ScanMode.BOOSTER -> getString(R.string.scan_mode_booster_header).substringAfter(' ')
                .uppercase(Locale.ROOT)
            ScanMode.SCHOOL -> getString(R.string.scan_mode_school_header).substringAfter(' ')
                .uppercase(Locale.ROOT)
            ScanMode.WORK -> getString(R.string.scan_mode_work_header).substringAfter(' ')
                .uppercase(Locale.ROOT)
            ScanMode.ENTRY_ITALY -> getString(R.string.scan_mode_entry_italy_header).substringAfter(
                ' '
            )
                .uppercase(Locale.ROOT)
        }
        val scanModeLabel = getString(R.string.label_scan_mode_ver)
        binding.scanModeText.text =
            getString(R.string.label_verification_scan_mode, scanModeLabel, chosenScanMode)
    }

    private fun setupTimeStamp(cert: CertificateViewBean) {
        binding.validationDate.text = getString(
            R.string.label_validation_timestamp, cert.timeStamp?.parseTo(
                FORMATTED_VALIDATION_DATE
            )
        )
        binding.validationDate.visibility = View.VISIBLE
    }

    private fun setLinkViews(certStatus: CertificateStatus) {
//        binding.questionContainer.removeAllViews()
//        val questionMap: Map<String, String> = when (certStatus) {
//            CertificateStatus.VALID -> mapOf(getString(R.string.label_what_can_be_done) to "https://www.dgc.gov.it/web/faq.html#verifica19")
//            CertificateStatus.NOT_VALID_YET -> mapOf(getString(R.string.label_when_qr_valid) to "https://www.dgc.gov.it/web/faq.html#verifica19")
//            CertificateStatus.NOT_VALID, CertificateStatus.EXPIRED, CertificateStatus.TEST_NEEDED, CertificateStatus.REVOKED -> mapOf(
//                getString(R.string.label_why_qr_not_valid) to "https://www.dgc.gov.it/web/faq.html#verifica19"
//            )
//            CertificateStatus.NOT_EU_DCC -> mapOf(getString(R.string.label_which_qr_scan) to "https://www.dgc.gov.it/web/faq.html#verifica19")
//        }
//        questionMap.map {
//            val compound = QuestionCompound(context)
//            compound.setupWithLabels(it.key, it.value)
//            binding.questionContainer.addView(compound)
//        }
//        binding.questionContainer.clipChildren = false
    }

    private fun setValidationSubTextVisibility(certStatus: CertificateStatus) {
//        binding.subtitleText.visibility = when (certStatus) {
//            CertificateStatus.NOT_EU_DCC -> View.GONE
//            else -> View.VISIBLE
//        }
    }

    private fun setValidationSubText(certStatus: CertificateStatus) {
//        binding.subtitleText.text =
//            when (certStatus) {
//                CertificateStatus.VALID, CertificateStatus.TEST_NEEDED -> getString(R.string.subtitle_text)
//                CertificateStatus.NOT_VALID, CertificateStatus.EXPIRED, CertificateStatus.NOT_VALID_YET -> getString(R.string.subtitle_text_notvalid)
//                else -> getString(R.string.subtitle_text_technicalError)
//            }
    }

    private fun setValidationMainText(certStatus: CertificateStatus) {
        binding.certificateValid.text = when (certStatus) {
            CertificateStatus.VALID -> getString(R.string.certificateValid)
            CertificateStatus.NOT_EU_DCC -> getString(R.string.certificateNotDCC)
            CertificateStatus.REVOKED -> if (isDebug()) getString(R.string.certificateRevoked) else getString(
                R.string.certificateNonValid
            )
            CertificateStatus.NOT_VALID -> getString(R.string.certificateNonValid)
            CertificateStatus.EXPIRED -> getString(R.string.certificateExpired)
            CertificateStatus.TEST_NEEDED -> getString(R.string.certificateValidTestNeeded)
            CertificateStatus.NOT_VALID_YET -> getString(R.string.certificateNonValidYet)
        }
    }

    private fun setValidationIcon(certStatus: CertificateStatus) {
        binding.checkmark.background =
            ContextCompat.getDrawable(
                requireContext(), when (certStatus) {
                    CertificateStatus.VALID -> R.drawable.ic_valid_cert
                    CertificateStatus.NOT_VALID_YET -> R.drawable.ic_not_valid_yet
                    CertificateStatus.NOT_EU_DCC -> R.drawable.ic_technical_error
                    CertificateStatus.TEST_NEEDED -> R.drawable.ic_warning
                    else -> R.drawable.ic_invalid
                }
            )
    }

    private fun setPersonDetailsVisibility(certStatus: CertificateStatus) {
//        binding.containerPersonDetails.visibility = when (certStatus) {
//            CertificateStatus.VALID, CertificateStatus.REVOKED, CertificateStatus.TEST_NEEDED, CertificateStatus.NOT_VALID,  CertificateStatus.EXPIRED, CertificateStatus.NOT_VALID_YET -> View.VISIBLE
//            else -> View.GONE
//        }
    }

    private fun setBackgroundColor(certStatus: CertificateStatus) {
        binding.verificationBackground.setBackgroundColor(
            ContextCompat.getColor(
                requireContext(),
                when (certStatus) {
                    CertificateStatus.VALID -> R.color.green
                    CertificateStatus.TEST_NEEDED -> R.color.orange
                    else -> R.color.red_bg
                }
            )
        )
    }

    private fun setPersonData(person: PersonModel?, dateOfBirth: String?) {
        if (person?.familyName.isNullOrEmpty()) {
            binding.nameStandardisedText.text = person?.standardisedFamilyName.plus(" ").plus(person?.standardisedGivenName).plus(" ").plus(person?.givenName)
        } else {
            binding.nameStandardisedText.text = person?.familyName.plus(" ").plus(person?.givenName)
        }
        binding.birthdateText.text = dateOfBirth?.formatDateOfBirth().orEmpty()
    }

    private fun setCertificateData(cert: CertificateModel) {

        if (cert.isValid)
        {
            binding.motivationLabel.visibility = View.GONE
            binding.motivationText.visibility = View.GONE
            val layout = binding.nameText.layoutParams as ConstraintLayout.LayoutParams
            layout.topToBottom = binding.certificateValid.id
            binding.certificate.text = cert.certificate.toString()

            binding.certificate.setOnClickListener {
                val clipboard = context?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText(cert.certificate.toString(), cert.certificate.toString())
                clipboard.setPrimaryClip(clip)
                val toast = Toast.makeText(context,"Certificate copiato nella clipboard", Toast.LENGTH_LONG)
                toast.show()
            }

        } else if (cert.isBlackListed)
        {
            binding.motivationText.text = "Blacklist"
        } else if (!cert.isCborDecoded) {
            binding.motivationText.text = "Formato non valido"
            binding.dateLabel.visibility = View.GONE
            binding.nameText.visibility = View.GONE
            binding.nameStandardisedText.visibility = View.GONE
            binding.typeLabel.visibility = View.GONE
            binding.idLabel.visibility = View.GONE
            binding.nationalityLabel.visibility = View.GONE
            binding.enteLabel.visibility = View.GONE
            binding.birthdateLabel.visibility = View.GONE
            binding.scadLabel.visibility = View.GONE
        } else if (cert.isRevoked) {
            binding.motivationText.text = "Revocato"
        } else {
            binding.motivationText.text = "Falso"
        }

        binding.idText.text = cert?.certificateIdentifier

        if (cert.hasVaccinations())
        {
            val v = cert.vaccinations?.last()

            binding.typeText.text = "VACCINO"
            binding.enteText.text = v?.certificateIssuer
            binding.nationalityText.text = v?.countryOfVaccination
            binding.dateText.text = v?.dateOfVaccination
            binding.scadLabel.text = "Tipo di vaccinazione:"

            if (v?.isNotComplete() == true)
            {
                binding.scadText.text = "Non completa ${v?.doseNumber}/${v?.totalSeriesOfDoses} (${v?.manufacturer} ${v?.medicinalProduct} ${v?.vaccine})"
            } else if (v?.isComplete() == true)
            {
                binding.scadText.text = "Completa ${v?.doseNumber}/${v?.totalSeriesOfDoses} (${v?.manufacturer} ${v?.medicinalProduct} ${v?.vaccine})"
            } else if (v?.isBooster() == true)
            {
                binding.scadText.text = "Booster ${v?.doseNumber}/${v?.totalSeriesOfDoses} (${v?.manufacturer} ${v?.medicinalProduct} ${v?.vaccine})"
            }

        }

        if (cert.hasRecoveries())
        {
            val r = cert.recoveryStatements?.last()

            binding.typeText.text = "GUARIGIONE"

            if (r?.isRecoveryBis(cert.certificate) == true)
            {
                binding.typeText.text = "GUARIGIONE (Definitiva)"
            }

            binding.enteText.text = r?.certificateIssuer
            binding.nationalityText.text = r?.country
            binding.dateText.text = r?.certificateValidFrom
            binding.scadText.text = r?.certificateValidUntil
//            binding.scadLabel.text = "Data di positività:"
//            binding.dateText.text = r?.dateOfFirstPositiveTest
        }

        if (cert.hasTests())
        {
            val t = cert.tests?.last()

            binding.typeText.text = "TAMPONE"
            binding.enteText.text = t?.certificateIssuer
            binding.nationalityText.text = t?.countryOfVaccination
            binding.dateText.text = t?.dateTimeOfTestResult
            binding.scadText.text = t?.dateTimeOfTestResult.plus("2d")

            " ${t?.dateTimeOfCollection}  ${t?.resultType} ${t?.testName} ${t?.testResult} ${t?.testingCentre} ${t?.typeOfTest} ${t?.disease}"
        }


    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.close_button -> findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun createForceUpdateDialog(message: String) {
        val builder = this.activity?.let { AlertDialog.Builder(requireContext()) }
        builder!!.setTitle(getString(R.string.updateTitle))
        builder.setMessage(message)
        builder.setPositiveButton(getString(R.string.ok)) { _, _ ->
            findNavController().popBackStack()
        }
        val dialog = builder.create()
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.show()
    }

}
